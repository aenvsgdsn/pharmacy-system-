# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to prepare project configuration or init upgrade options: Invalid URL. Please check the project configuration and try again.
  
  
  - ###
    ### ✅ Install JDK 15
  </details>